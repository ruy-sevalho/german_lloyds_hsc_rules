from setuptools import setup, find_packages

setup(author='Ruy Sevalho', name='gl_hsc_scantling', packages=['gl_hsc_scantling']) #where='gl_hsc_scantling'