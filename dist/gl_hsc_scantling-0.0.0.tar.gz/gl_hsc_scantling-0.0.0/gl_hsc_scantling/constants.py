# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 10:02:04 2020

@author: ruy
"""

gravity = 9.81 # m/s²
water_rho = 1.025 # ton/m³